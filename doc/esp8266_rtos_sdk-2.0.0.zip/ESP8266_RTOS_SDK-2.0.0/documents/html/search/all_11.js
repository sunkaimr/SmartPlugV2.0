var searchData=
[
  ['type',['type',['../structespconn.html#a2431ce92ac5c0bda2b6e5812ba8e3323',1,'espconn']]]
];
