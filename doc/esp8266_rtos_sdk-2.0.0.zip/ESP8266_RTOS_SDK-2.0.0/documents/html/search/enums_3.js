var searchData=
[
  ['flash_5fsize_5fmap',['flash_size_map',['../group__System__boot__APIs.html#ga09fedddfc198c6f5b12e795d7a560de2',1,'esp_system.h']]]
];
