var searchData=
[
  ['reason',['reason',['../structrst__info.html#af5b53fbb4b238f9aa0261eed1236b9ba',1,'rst_info::reason()'],['../structEvent__StaMode__Disconnected__t.html#abf07e8ad67430e516654d1b8d42b9731',1,'Event_StaMode_Disconnected_t::reason()']]],
  ['reason_5fdeep_5fsleep_5fawake',['REASON_DEEP_SLEEP_AWAKE',['../group__System__APIs.html#ggaf560461b4a37405f75fd789165f6c576acee6519d545f6be1bac3e00be8637ee7',1,'esp_system.h']]],
  ['reason_5fdefault_5frst',['REASON_DEFAULT_RST',['../group__System__APIs.html#ggaf560461b4a37405f75fd789165f6c576af39e71277c3bfc84b75a4a5683531565',1,'esp_system.h']]],
  ['reason_5fexception_5frst',['REASON_EXCEPTION_RST',['../group__System__APIs.html#ggaf560461b4a37405f75fd789165f6c576a37032d096425911146ce105004cc8adb',1,'esp_system.h']]],
  ['reason_5fext_5fsys_5frst',['REASON_EXT_SYS_RST',['../group__System__APIs.html#ggaf560461b4a37405f75fd789165f6c576a9ab5cbcccb384a176990019a8e1b2cc8',1,'esp_system.h']]],
  ['reason_5fsoft_5frestart',['REASON_SOFT_RESTART',['../group__System__APIs.html#ggaf560461b4a37405f75fd789165f6c576a6d052f0a22d1b1d060a7e017f6152559',1,'esp_system.h']]],
  ['reason_5fsoft_5fwdt_5frst',['REASON_SOFT_WDT_RST',['../group__System__APIs.html#ggaf560461b4a37405f75fd789165f6c576a57184a4fb4d760f85fd0834566bf6e9c',1,'esp_system.h']]],
  ['reason_5fwdt_5frst',['REASON_WDT_RST',['../group__System__APIs.html#ggaf560461b4a37405f75fd789165f6c576a90f8f58c2fec687ee00f4735bf24006d',1,'esp_system.h']]],
  ['reconnect_5fcallback',['reconnect_callback',['../struct__esp__tcp.html#a7dfb00c9f12a97566da16c71bebd253b',1,'_esp_tcp']]],
  ['recv_5fcallback',['recv_callback',['../structespconn.html#a66d8db64dbb623bab3e442dd923371b5',1,'espconn']]],
  ['remote_5fip',['remote_ip',['../struct__esp__tcp.html#a1e97206aeb1c8767a07fba34b0e10630',1,'_esp_tcp::remote_ip()'],['../struct__esp__udp.html#a1e97206aeb1c8767a07fba34b0e10630',1,'_esp_udp::remote_ip()'],['../struct__remot__info.html#a1e97206aeb1c8767a07fba34b0e10630',1,'_remot_info::remote_ip()']]],
  ['remote_5fport',['remote_port',['../struct__esp__tcp.html#a50c260a2144cb980f505670e1ea22ccd',1,'_esp_tcp::remote_port()'],['../struct__esp__udp.html#a50c260a2144cb980f505670e1ea22ccd',1,'_esp_udp::remote_port()'],['../struct__remot__info.html#a50c260a2144cb980f505670e1ea22ccd',1,'_remot_info::remote_port()']]],
  ['reserve',['reserve',['../structespconn.html#aaaa8d264a32f8754cf0ffa69f70d8f8d',1,'espconn']]],
  ['rfid_5flocp_5fcb_5ft',['rfid_locp_cb_t',['../group__WiFi__Common__APIs.html#gae1c8898c72bc7b1dde854068662527bc',1,'esp_wifi.h']]],
  ['rssi',['rssi',['../structbss__info.html#a919873edc1a7b2795e7efc5b9108ef53',1,'bss_info::rssi()'],['../structEvent__SoftAPMode__ProbeReqRecved__t.html#ab6f4522a5a5c4577c16d0e23339a1414',1,'Event_SoftAPMode_ProbeReqRecved_t::rssi()']]],
  ['rst_5finfo',['rst_info',['../structrst__info.html',1,'']]],
  ['rst_5freason',['rst_reason',['../group__System__APIs.html#gaf560461b4a37405f75fd789165f6c576',1,'esp_system.h']]],
  ['rate_20control_20apis',['Rate Control APIs',['../group__WiFi__Rate__Control__APIs.html',1,'']]]
];
